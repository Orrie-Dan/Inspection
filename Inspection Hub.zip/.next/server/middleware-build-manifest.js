globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/fdf1351a26d285b0.js",
    "static/chunks/183e6018a8a15049.js",
    "static/chunks/ac11ee233e0e1386.js",
    "static/chunks/d7f10e9650596532.js",
    "static/chunks/2151b12fe61cfd0c.js",
    "static/chunks/turbopack-6ec922d4461ba6e5.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];