module.exports=[67234,(a,b,c)=>{}];

//# sourceMappingURL=Downloads_Inspection%20Dashboard__next-internal_server_app_page_actions_8bda6d14.js.map