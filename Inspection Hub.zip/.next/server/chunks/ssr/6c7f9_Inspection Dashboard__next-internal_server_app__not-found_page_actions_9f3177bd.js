module.exports=[71489,(a,b,c)=>{}];

//# sourceMappingURL=6c7f9_Inspection%20Dashboard__next-internal_server_app__not-found_page_actions_9f3177bd.js.map