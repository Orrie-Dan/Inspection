module.exports=[8920,(a,b,c)=>{}];

//# sourceMappingURL=6c7f9_Inspection%20Dashboard__next-internal_server_app_login_page_actions_b07c3d5d.js.map