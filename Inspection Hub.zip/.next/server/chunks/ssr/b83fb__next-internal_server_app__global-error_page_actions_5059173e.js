module.exports=[16357,(a,b,c)=>{}];

//# sourceMappingURL=b83fb__next-internal_server_app__global-error_page_actions_5059173e.js.map