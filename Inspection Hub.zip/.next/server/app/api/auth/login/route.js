var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/login/route.js")
R.c("server/chunks/[root-of-the-server]__0dc5b095._.js")
R.c("server/chunks/[root-of-the-server]__1e22e4e0._.js")
R.c("server/chunks/b83fb__next-internal_server_app_api_auth_login_route_actions_bea933e6.js")
R.m(99114)
module.exports=R.m(99114).exports
