(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_1e11edb6._.js",
  "static/chunks/04185_next_dist_compiled_react-dom_4cd3751a._.js",
  "static/chunks/04185_next_dist_compiled_react-server-dom-turbopack_ac3d361f._.js",
  "static/chunks/04185_next_dist_compiled_next-devtools_index_eaceae1a.js",
  "static/chunks/04185_next_dist_compiled_db0ed0e2._.js",
  "static/chunks/04185_next_dist_client_f0c19591._.js",
  "static/chunks/04185_next_dist_8396eecd._.js",
  "static/chunks/04185_@swc_helpers_cjs_84bc363c._.js"
],
    source: "entry"
});
