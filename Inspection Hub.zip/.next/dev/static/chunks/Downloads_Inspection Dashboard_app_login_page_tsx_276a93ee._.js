(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/04185_0c3d9091._.js",
  "static/chunks/Downloads_Inspection Dashboard_e513e158._.js"
],
    source: "dynamic"
});
