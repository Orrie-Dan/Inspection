(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/04185_225be485._.js",
  "static/chunks/Downloads_Inspection Dashboard_635ae34e._.js"
],
    source: "dynamic"
});
