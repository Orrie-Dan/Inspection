module.exports = [
"[project]/Downloads/Inspection Dashboard/.next-internal/server/app/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=Downloads_Inspection%20Dashboard__next-internal_server_app_page_actions_8bda6d14.js.map