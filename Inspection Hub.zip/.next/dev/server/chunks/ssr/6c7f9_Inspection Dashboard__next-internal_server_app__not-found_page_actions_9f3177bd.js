module.exports = [
"[project]/Downloads/Inspection Dashboard/.next-internal/server/app/_not-found/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=6c7f9_Inspection%20Dashboard__next-internal_server_app__not-found_page_actions_9f3177bd.js.map